
import React, { useState } from 'react';
import { HashRouter, Routes, Route, NavLink } from 'react-router-dom';
import { HomeIcon, PlantIcon, MicroscopeIcon, ChartIcon, NewspaperIcon, MenuIcon, XIcon, JournalIcon } from './constants';
import Dashboard from './components/Dashboard';
import CropDoctor from './components/CropDoctor';
import CropPlanner from './components/CropPlanner';
import MarketWatch from './components/MarketWatch';
import AgriNews from './components/AgriNews';
import FarmJournal from './components/FarmJournal';

const App: React.FC = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const navLinks = [
        { to: "/", icon: <HomeIcon />, text: "Dashboard" },
        { to: "/crop-doctor", icon: <MicroscopeIcon />, text: "Crop Doctor" },
        { to: "/crop-planner", icon: <PlantIcon />, text: "Crop Planner" },
        { to: "/market-watch", icon: <ChartIcon />, text: "Market Watch" },
        { to: "/agri-news", icon: <NewspaperIcon />, text: "Agri-News" },
        { to: "/farm-journal", icon: <JournalIcon />, text: "Farm Journal" },
    ];

    const NavContent = () => (
        <nav className="mt-10">
            {navLinks.map((link) => (
                <NavLink
                    key={link.to}
                    to={link.to}
                    onClick={() => setIsMenuOpen(false)}
                    className={({ isActive }) =>
                        `flex items-center px-4 py-3 my-2 text-lg transition-colors duration-200 transform rounded-md ${
                        isActive
                            ? 'bg-brand-green-dark text-white'
                            : 'text-gray-200 hover:bg-brand-green-dark hover:text-white'
                        }`
                    }
                >
                    {link.icon}
                    <span className="mx-4 font-medium">{link.text}</span>
                </NavLink>
            ))}
        </nav>
    );

    return (
        <HashRouter>
            <div className="flex h-screen bg-brand-gray font-sans">
                {/* Desktop Sidebar */}
                <aside className="hidden w-64 flex-shrink-0 bg-brand-green text-white md:block">
                    <div className="flex flex-col h-full p-4">
                        <div className="text-2xl font-bold font-serif flex items-center">
                            <PlantIcon className="w-8 h-8 mr-2"/>
                            Agri-Assistant
                        </div>
                        <NavContent />
                    </div>
                </aside>

                {/* Mobile Sidebar */}
                <div className={`fixed inset-0 z-30 transition-opacity bg-black opacity-50 md:hidden ${isMenuOpen ? 'block' : 'hidden'}`} onClick={() => setIsMenuOpen(false)}></div>
                <div className={`fixed inset-y-0 left-0 z-40 w-64 px-4 py-7 overflow-y-auto transition duration-300 transform bg-brand-green md:hidden ${isMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
                    <div className="flex items-center justify-between">
                        <div className="text-2xl font-bold font-serif flex items-center text-white">
                            <PlantIcon className="w-8 h-8 mr-2"/>
                            Agri-Assistant
                        </div>
                        <button onClick={() => setIsMenuOpen(false)}>
                            <XIcon className="w-6 h-6 text-white"/>
                        </button>
                    </div>
                    <NavContent />
                </div>

                <div className="flex-1 flex flex-col overflow-hidden">
                    <header className="flex items-center justify-between p-4 bg-white border-b md:hidden">
                         <div className="text-xl font-bold font-serif text-brand-green">Agri-Assistant</div>
                        <button onClick={() => setIsMenuOpen(!isMenuOpen)}>
                            <MenuIcon className="w-6 h-6 text-gray-600" />
                        </button>
                    </header>
                    <main className="flex-1 overflow-x-hidden overflow-y-auto bg-brand-gray p-4 sm:p-6 lg:p-8">
                        <Routes>
                            <Route path="/" element={<Dashboard />} />
                            <Route path="/crop-doctor" element={<CropDoctor />} />
                            <Route path="/crop-planner" element={<CropPlanner />} />
                            <Route path="/market-watch" element={<MarketWatch />} />
                            <Route path="/agri-news" element={<AgriNews />} />
                            <Route path="/farm-journal" element={<FarmJournal />} />
                        </Routes>
                    </main>
                </div>
            </div>
        </HashRouter>
    );
};

export default App;
