
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { CropPlan, GroundingChunk, JournalEntry } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

// Helper to convert file to base64
const fileToGenerativePart = async (file: File) => {
    const base64EncodedDataPromise = new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            if (typeof reader.result === 'string') {
                resolve(reader.result.split(',')[1]);
            } else {
                resolve('');
            }
        };
        reader.readAsDataURL(file);
    });
    return {
        inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
    };
};

export const diagnoseCropIssue = async (imageFile: File, prompt: string) => {
    const imagePart = await fileToGenerativePart(imageFile);
    const textPart = { text: prompt };

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [imagePart, textPart] },
        config: {
            temperature: 0.2,
            topP: 0.8,
            topK: 32,
        }
    });

    return response.text;
};

export const getCropPlan = async (location: string, soilType: string, landSize: string): Promise<CropPlan[]> => {
    const prompt = `
        Create a detailed, year-round crop rotation plan for a farmer with the following conditions:
        - Location: ${location}
        - Soil Type: ${soilType}
        - Land Size: ${landSize} acres

        The plan should be suitable for the specified location's climate.
        Provide a list of plans, with each plan containing:
        1. "season": (e.g., "Spring (March-May)")
        2. "crops": A list of suitable crops to plant.
        3. "planting_schedule": A brief description of when to plant during the season.
        4. "harvesting_schedule": A brief description of when to expect the harvest.
        5. "notes": Important considerations or tips for that season (e.g., soil preparation, pest control).
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        season: { type: Type.STRING },
                        crops: { type: Type.ARRAY, items: { type: Type.STRING } },
                        planting_schedule: { type: Type.STRING },
                        harvesting_schedule: { type: Type.STRING },
                        notes: { type: Type.STRING },
                    },
                    required: ["season", "crops", "planting_schedule", "harvesting_schedule", "notes"],
                },
            },
        },
    });

    const jsonText = response.text.trim();
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        console.error("Failed to parse JSON response for crop plan:", e);
        // Attempt to fix malformed JSON if possible (basic fixes)
        const fixedJson = jsonText.replace(/,\s*]/g, ']').replace(/,\s*}/g, '}');
        try {
            return JSON.parse(fixedJson);
        } catch (e2) {
            console.error("Failed to parse even after fixing JSON:", e2);
            return [];
        }
    }
};

export const getMarketData = async (crop: string): Promise<{ summary: string, sources: GroundingChunk[] }> => {
    const prompt = `Provide a market analysis for ${crop}. Include current price trends, future outlook, and any factors affecting the price.`;
    
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            tools: [{ googleSearch: {} }],
        },
    });

    const summary = response.text;
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    return { summary, sources: sources as GroundingChunk[] };
};

export const getAgriNews = async (): Promise<{ summary: string, sources: GroundingChunk[] }> => {
    const prompt = "What are the latest top 5 news and innovations in agriculture globally? Summarize them.";
    
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            tools: [{ googleSearch: {} }],
        },
    });
    
    const summary = response.text;
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

    return { summary, sources: sources as GroundingChunk[] };
};

export const analyzeJournal = async (entries: JournalEntry[]): Promise<string> => {
    const formattedEntries = entries.map(e => 
        `- Date: ${new Date(e.date).toLocaleDateString()}, Category: ${e.category}, Title: ${e.title}, Details: ${e.details}`
    ).join('\n');

    const prompt = `
        I am a farmer/gardener. Here are my journal entries for my farm/garden:
        ${formattedEntries}

        Based on these entries, please provide a concise analysis of my activities.
        Your analysis should include:
        1.  **Activity Summary:** A brief overview of what I've been doing (e.g., "You've been busy with planting and pest observation.").
        2.  **Potential Insights:** Point out any interesting patterns, correlations, or potential issues you see. For example, if I noted pests shortly after fertilizing, you could mention that.
        3.  **Actionable Suggestions:** Provide 2-3 concrete suggestions for what I could do next or how I could improve my practices based on the log.

        Keep the tone encouraging and helpful. Format the response in clear, easy-to-read markdown.
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            temperature: 0.5,
        }
    });

    return response.text;
};
