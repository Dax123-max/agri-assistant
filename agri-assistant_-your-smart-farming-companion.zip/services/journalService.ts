
import { JournalEntry } from '../types';

const JOURNAL_KEY = 'agriAssistantJournalEntries';

export const getJournalEntries = (): JournalEntry[] => {
    try {
        const entriesJson = localStorage.getItem(JOURNAL_KEY);
        if (entriesJson) {
            return JSON.parse(entriesJson);
        }
    } catch (error) {
        console.error("Could not parse journal entries from localStorage", error);
    }
    return [];
};

export const addJournalEntry = (entry: Omit<JournalEntry, 'id' | 'date'>): JournalEntry[] => {
    const entries = getJournalEntries();
    const newEntry: JournalEntry = {
        ...entry,
        id: new Date().toISOString() + Math.random().toString(36).substr(2, 9),
        date: new Date().toISOString(),
    };
    const updatedEntries = [newEntry, ...entries];
    try {
        localStorage.setItem(JOURNAL_KEY, JSON.stringify(updatedEntries));
    } catch (error) {
        console.error("Could not save journal entries to localStorage", error);
    }
    return updatedEntries;
};

export const deleteJournalEntry = (id: string): JournalEntry[] => {
    const entries = getJournalEntries();
    const updatedEntries = entries.filter(entry => entry.id !== id);
    try {
        localStorage.setItem(JOURNAL_KEY, JSON.stringify(updatedEntries));
    } catch (error) {
        console.error("Could not save journal entries to localStorage", error);
    }
    return updatedEntries;
};
