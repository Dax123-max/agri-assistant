
export interface CropPlan {
    season: string;
    crops: string[];
    planting_schedule: string;
    harvesting_schedule: string;
    notes: string;
}

export interface MarketData {
    crop: string;
    price_trends: { date: string; price: number }[];
    summary: string;
    news: { title: string; url: string }[];
}

export interface NewsArticle {
    title: string;
    summary: string;
    url: string;
    source: string;
}

export interface GroundingChunk {
    web: {
        uri: string;
        title: string;
    }
}

export interface JournalEntry {
    id: string;
    title: string;
    details: string;
    category: string;
    date: string;
}
