
import React from 'react';
import { NavLink } from 'react-router-dom';
import Card from './common/Card';
import { MicroscopeIcon, PlantIcon, ChartIcon, NewspaperIcon } from '../constants';

const Dashboard: React.FC = () => {
    const features = [
        {
            title: "Crop Doctor",
            description: "Upload an image of a plant to diagnose diseases or pests and get treatment advice.",
            link: "/crop-doctor",
            icon: <MicroscopeIcon className="w-12 h-12 text-brand-green" />,
            color: "green"
        },
        {
            title: "Crop Planner",
            description: "Get a customized, year-round crop rotation plan based on your location and soil.",
            link: "/crop-planner",
            icon: <PlantIcon className="w-12 h-12 text-brand-brown" />,
            color: "brown"
        },
        {
            title: "Market Watch",
            description: "Stay updated with the latest market prices and trends for your crops.",
            link: "/market-watch",
            icon: <ChartIcon className="w-12 h-12 text-brand-blue" />,
            color: "blue"
        },
        {
            title: "Agri-News",
            description: "Discover the latest news and innovations in the world of agriculture.",
            link: "/agri-news",
            icon: <NewspaperIcon className="w-12 h-12 text-gray-600" />,
            color: "gray"
        }
    ];

    return (
        <div className="animate-fade-in">
            <div className="text-center md:text-left mb-8">
                <h1 className="text-4xl font-bold font-serif text-gray-800">Welcome to Agri-Assistant</h1>
                <p className="mt-2 text-lg text-gray-600">Your smart companion for a revolutionary farming experience.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
                {features.map((feature) => (
                    <NavLink to={feature.link} key={feature.title} className="transform hover:-translate-y-1 transition-transform duration-300">
                        <Card className="h-full">
                            <div className="flex items-start">
                                <div className="flex-shrink-0">
                                    {feature.icon}
                                </div>
                                <div className="ml-5">
                                    <h2 className="text-2xl font-bold text-gray-900">{feature.title}</h2>
                                    <p className="mt-2 text-gray-600">{feature.description}</p>
                                </div>
                            </div>
                        </Card>
                    </NavLink>
                ))}
            </div>
             <div className="mt-8">
                <Card>
                    <div className="flex flex-col md:flex-row items-center">
                        <img src="https://picsum.photos/400/250?random=1" alt="Farm" className="rounded-lg shadow-lg w-full md:w-1/3 object-cover" />
                        <div className="mt-6 md:mt-0 md:ml-8">
                            <h3 className="text-2xl font-bold font-serif text-gray-800">Our Mission</h3>
                            <p className="mt-4 text-gray-600">
                                To empower farmers and agricultural enthusiasts by providing accessible, innovative, and data-driven tools. We believe in leveraging technology to make farming more sustainable, efficient, and profitable for everyone. From the smallest backyard garden to large-scale farms, Agri-Assistant is here to help you grow.
                            </p>
                        </div>
                    </div>
                </Card>
            </div>
        </div>
    );
};

export default Dashboard;
