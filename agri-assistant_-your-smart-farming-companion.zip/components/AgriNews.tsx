
import React, { useState, useEffect, useCallback } from 'react';
import Card from './common/Card';
import Spinner from './common/Spinner';
import { getAgriNews } from '../services/geminiService';
import { GroundingChunk } from '../types';
import ReactMarkdown from 'react-markdown';

const AgriNews: React.FC = () => {
    const [newsSummary, setNewsSummary] = useState<string>('');
    const [sources, setSources] = useState<GroundingChunk[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string>('');

    const fetchNews = useCallback(async () => {
        setLoading(true);
        setError('');
        try {
            const { summary, sources } = await getAgriNews();
            setNewsSummary(summary);
            setSources(sources);
        } catch (err) {
            setError('Failed to fetch agricultural news. Please try again later.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchNews();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <div className="animate-fade-in">
            <h1 className="text-4xl font-bold font-serif text-gray-800 mb-2">Agricultural News & Innovations</h1>
            <p className="text-lg text-gray-600 mb-6">Your daily digest of the latest happenings in the world of agriculture.</p>
            
            <div className="text-right mb-4">
                <button
                    onClick={fetchNews}
                    disabled={loading}
                    className="bg-brand-green hover:bg-brand-green-dark text-white font-bold py-2 px-4 rounded-lg transition duration-300 disabled:bg-gray-400"
                >
                    {loading ? 'Refreshing...' : 'Refresh News'}
                </button>
            </div>
            
            <Card>
                {loading && <Spinner />}
                {error && <p className="text-center text-red-500">{error}</p>}
                {!loading && !error && (
                    <>
                        <div className="prose prose-lg max-w-none prose-h2:font-serif prose-h2:text-brand-green prose-strong:text-brand-brown">
                            <ReactMarkdown>{newsSummary}</ReactMarkdown>
                        </div>
                        {sources.length > 0 && (
                            <div className="mt-8 border-t pt-6">
                                <h3 className="font-semibold text-gray-700 text-xl">Sources:</h3>
                                <ul className="list-disc list-inside mt-3 text-sm space-y-2">
                                    {sources.map((source, index) => (
                                        <li key={index}>
                                            <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-brand-blue hover:underline">
                                                {source.web.title || source.web.uri}
                                            </a>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </>
                )}
            </Card>
        </div>
    );
};

export default AgriNews;
