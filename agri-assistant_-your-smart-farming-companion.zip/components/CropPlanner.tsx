
import React, { useState, useCallback } from 'react';
import Card from './common/Card';
import Spinner from './common/Spinner';
import { getCropPlan } from '../services/geminiService';
import { CropPlan } from '../types';

const CropPlanner: React.FC = () => {
    const [location, setLocation] = useState<string>('');
    const [soilType, setSoilType] = useState<string>('');
    const [landSize, setLandSize] = useState<string>('');
    const [plan, setPlan] = useState<CropPlan[] | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string>('');

    const handleSubmit = useCallback(async (e: React.FormEvent) => {
        e.preventDefault();
        if (!location || !soilType || !landSize) {
            setError('Please fill in all fields.');
            return;
        }
        setLoading(true);
        setError('');
        setPlan(null);

        try {
            const result = await getCropPlan(location, soilType, landSize);
            setPlan(result);
        } catch (err) {
            setError('Failed to generate a plan. Please try again.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, [location, soilType, landSize]);

    return (
        <div className="animate-fade-in">
            <h1 className="text-4xl font-bold font-serif text-gray-800 mb-2">Crop Planner</h1>
            <p className="text-lg text-gray-600 mb-6">Get a tailored crop rotation plan for your farm.</p>

            <Card className="mb-8">
                <form onSubmit={handleSubmit}>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <label htmlFor="location" className="block text-sm font-medium text-gray-700">Location (e.g., Central Valley, California)</label>
                            <input type="text" id="location" value={location} onChange={(e) => setLocation(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-green focus:border-brand-green" />
                        </div>
                        <div>
                            <label htmlFor="soilType" className="block text-sm font-medium text-gray-700">Soil Type (e.g., Loamy, Clay, Sandy)</label>
                            <input type="text" id="soilType" value={soilType} onChange={(e) => setSoilType(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-green focus:border-brand-green" />
                        </div>
                        <div>
                            <label htmlFor="landSize" className="block text-sm font-medium text-gray-700">Land Size (in acres)</label>
                            <input type="number" id="landSize" value={landSize} onChange={(e) => setLandSize(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-green focus:border-brand-green" />
                        </div>
                    </div>
                    <div className="mt-6 text-center">
                        <button type="submit" disabled={loading} className="w-full md:w-auto bg-brand-green hover:bg-brand-green-dark text-white font-bold py-3 px-8 rounded-lg transition duration-300 disabled:bg-gray-400">
                            {loading ? 'Generating Plan...' : 'Generate Plan'}
                        </button>
                    </div>
                </form>
                {error && <p className="mt-4 text-center text-red-500">{error}</p>}
            </Card>

            {loading && <Spinner />}

            {plan && (
                <div className="space-y-6">
                    <h2 className="text-3xl font-bold font-serif text-center text-gray-800">Your Customized Crop Plan</h2>
                    {plan.map((seasonPlan, index) => (
                        <Card key={index}>
                            <h3 className="text-2xl font-bold text-brand-green mb-4">{seasonPlan.season}</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                                <div>
                                    <h4 className="font-semibold text-brand-brown">Suggested Crops:</h4>
                                    <ul className="list-disc list-inside text-gray-700">
                                        {seasonPlan.crops.map((crop, i) => <li key={i}>{crop}</li>)}
                                    </ul>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-brand-brown">Planting Schedule:</h4>
                                    <p className="text-gray-700">{seasonPlan.planting_schedule}</p>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-brand-brown">Harvesting Schedule:</h4>
                                    <p className="text-gray-700">{seasonPlan.harvesting_schedule}</p>
                                </div>
                                <div className="md:col-span-2">
                                    <h4 className="font-semibold text-brand-brown">Notes & Tips:</h4>
                                    <p className="text-gray-700">{seasonPlan.notes}</p>
                                </div>
                            </div>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    );
};

export default CropPlanner;
