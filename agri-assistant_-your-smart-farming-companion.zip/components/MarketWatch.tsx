
import React, { useState, useCallback } from 'react';
import Card from './common/Card';
import Spinner from './common/Spinner';
import { getMarketData } from '../services/geminiService';
import { GroundingChunk } from '../types';
import ReactMarkdown from 'react-markdown';

const popularCrops = ["Wheat", "Corn", "Soybeans", "Rice", "Cotton", "Tomatoes", "Potatoes", "Apples"];

const MarketWatch: React.FC = () => {
    const [crop, setCrop] = useState<string>('');
    const [customCrop, setCustomCrop] = useState<string>('');
    const [marketAnalysis, setMarketAnalysis] = useState<string>('');
    const [sources, setSources] = useState<GroundingChunk[]>([]);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string>('');

    const fetchMarketData = useCallback(async (cropToFetch: string) => {
        if (!cropToFetch) {
            setError('Please select or enter a crop.');
            return;
        }
        setLoading(true);
        setError('');
        setMarketAnalysis('');
        setSources([]);

        try {
            const { summary, sources } = await getMarketData(cropToFetch);
            setMarketAnalysis(summary);
            setSources(sources);
        } catch (err) {
            setError('Failed to fetch market data. Please try again.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, []);

    const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const selectedCrop = e.target.value;
        setCrop(selectedCrop);
        setCustomCrop('');
        if (selectedCrop) {
            fetchMarketData(selectedCrop);
        }
    };

    const handleFormSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        fetchMarketData(customCrop);
    };

    return (
        <div className="animate-fade-in">
            <h1 className="text-4xl font-bold font-serif text-gray-800 mb-2">Market Watch</h1>
            <p className="text-lg text-gray-600 mb-6">Get the latest market analysis and price trends for your crops.</p>

            <Card className="mb-8">
                <div className="flex flex-wrap items-center gap-4">
                    <div className="flex-grow">
                        <label htmlFor="crop-select" className="sr-only">Select a crop</label>
                        <select
                            id="crop-select"
                            value={crop}
                            onChange={handleSelectChange}
                            className="w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-green focus:border-brand-green"
                        >
                            <option value="">-- Select a popular crop --</option>
                            {popularCrops.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    </div>
                    <span className="text-gray-500">OR</span>
                    <form onSubmit={handleFormSubmit} className="flex-grow flex items-center gap-2">
                         <label htmlFor="custom-crop" className="sr-only">Enter a custom crop</label>
                        <input
                            id="custom-crop"
                            type="text"
                            value={customCrop}
                            onChange={(e) => { setCustomCrop(e.target.value); setCrop(''); }}
                            placeholder="Enter crop name (e.g., Avocado)"
                            className="w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-green focus:border-brand-green"
                        />
                        <button type="submit" disabled={loading || !customCrop} className="bg-brand-blue hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition duration-300 disabled:bg-gray-400">
                            Search
                        </button>
                    </form>
                </div>
                 {error && <p className="mt-4 text-center text-red-500">{error}</p>}
            </Card>

            {loading && <Spinner />}

            {marketAnalysis && (
                <Card>
                    <div className="prose prose-lg max-w-none prose-h2:font-serif prose-h2:text-brand-blue prose-strong:text-brand-brown">
                        <h2 className="!mb-4">Market Analysis for {crop || customCrop}</h2>
                        <ReactMarkdown>{marketAnalysis}</ReactMarkdown>
                    </div>
                    {sources.length > 0 && (
                        <div className="mt-6">
                            <h3 className="font-semibold text-gray-700">Sources:</h3>
                            <ul className="list-disc list-inside mt-2 text-sm space-y-1">
                                {sources.map((source, index) => (
                                    <li key={index}>
                                        <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-brand-blue hover:underline">
                                            {source.web.title || source.web.uri}
                                        </a>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    )}
                </Card>
            )}
        </div>
    );
};

export default MarketWatch;
