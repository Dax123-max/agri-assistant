
import React, { useState, useCallback } from 'react';
import Card from './common/Card';
import Spinner from './common/Spinner';
import { diagnoseCropIssue } from '../services/geminiService';
import { UploadIcon } from '../constants';
import ReactMarkdown from 'react-markdown';

const CropDoctor: React.FC = () => {
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const [analysis, setAnalysis] = useState<string>('');
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string>('');

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            setImageFile(file);
            setPreviewUrl(URL.createObjectURL(file));
            setAnalysis('');
            setError('');
        }
    };

    const handleDiagnose = useCallback(async () => {
        if (!imageFile) {
            setError('Please upload an image first.');
            return;
        }

        setLoading(true);
        setError('');
        setAnalysis('');

        try {
            const prompt = `Analyze this image of a plant. Identify any potential diseases or pests. Provide a detailed analysis including:
1.  **Identification:** What is the likely disease or pest?
2.  **Symptoms:** Describe the symptoms shown in the image and other common symptoms.
3.  **Causes:** What are the common causes for this issue?
4.  **Organic Treatment:** Suggest some organic or natural treatment options.
5.  **Chemical Treatment:** Suggest relevant chemical treatments if applicable.
6.  **Prevention:** Provide tips to prevent this issue in the future.
Format the response in clear, easy-to-read markdown.`;
            const result = await diagnoseCropIssue(imageFile, prompt);
            setAnalysis(result);
        } catch (err) {
            setError('An error occurred while analyzing the image. Please try again.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, [imageFile]);
    
    return (
        <div className="animate-fade-in">
            <h1 className="text-4xl font-bold font-serif text-gray-800 mb-2">Crop Doctor</h1>
            <p className="text-lg text-gray-600 mb-6">Upload a photo of a plant to identify diseases and get expert advice.</p>
            
            <Card>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Left Column: Uploader and Image Preview */}
                    <div className="flex flex-col items-center">
                        <div className="w-full max-w-md">
                            <label htmlFor="file-upload" className="cursor-pointer block w-full p-6 border-2 border-dashed border-gray-300 rounded-lg text-center hover:border-brand-green">
                                {previewUrl ? (
                                    <img src={previewUrl} alt="Plant preview" className="mx-auto max-h-64 rounded-lg object-contain" />
                                ) : (
                                    <div>
                                        <UploadIcon />
                                        <p className="mt-2 text-sm text-gray-600">
                                            <span className="font-semibold">Click to upload</span> or drag and drop
                                        </p>
                                        <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
                                    </div>
                                )}
                            </label>
                            <input id="file-upload" name="file-upload" type="file" className="sr-only" accept="image/*" onChange={handleFileChange} />
                        </div>
                        {imageFile && (
                            <div className="mt-4 text-center w-full max-w-md">
                               <p className="text-sm text-gray-500 truncate">{imageFile.name}</p>
                                <button
                                    onClick={handleDiagnose}
                                    disabled={loading}
                                    className="mt-4 w-full bg-brand-green hover:bg-brand-green-dark text-white font-bold py-3 px-4 rounded-lg transition duration-300 disabled:bg-gray-400 flex items-center justify-center"
                                >
                                    {loading ? 'Analyzing...' : 'Diagnose Plant'}
                                </button>
                            </div>
                        )}
                    </div>
                    
                    {/* Right Column: Analysis Result */}
                    <div className="prose prose-lg max-w-none prose-h1:font-serif prose-h1:text-brand-green prose-h2:text-gray-800 prose-strong:text-brand-brown">
                        <h2 className="text-2xl font-bold text-gray-800 border-b pb-2">Analysis Result</h2>
                        {loading && <Spinner />}
                        {error && <p className="text-red-500">{error}</p>}
                        {analysis ? (
                           <ReactMarkdown>{analysis}</ReactMarkdown>
                        ) : (
                           !loading && <p className="text-gray-500">Your plant's health analysis will appear here.</p>
                        )}
                    </div>
                </div>
            </Card>
        </div>
    );
};

export default CropDoctor;
