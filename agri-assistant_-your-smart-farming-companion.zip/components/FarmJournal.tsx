
import React, { useState, useEffect, useCallback } from 'react';
import Card from './common/Card';
import Spinner from './common/Spinner';
import { TrashIcon, LightbulbIcon } from '../constants';
import { JournalEntry } from '../types';
import * as journalService from '../services/journalService';
import * as geminiService from '../services/geminiService';
import ReactMarkdown from 'react-markdown';

const FarmJournal: React.FC = () => {
    const [entries, setEntries] = useState<JournalEntry[]>([]);
    const [title, setTitle] = useState('');
    const [details, setDetails] = useState('');
    const [category, setCategory] = useState('Observation');
    const [analysis, setAnalysis] = useState('');
    const [loadingAnalysis, setLoadingAnalysis] = useState(false);
    const [error, setError] = useState('');

    const entryCategories = ["Observation", "Planting", "Watering", "Fertilizing", "Pest Control", "Harvest"];
    
    const categoryColors: { [key: string]: string } = {
        "Observation": "bg-purple-100 text-purple-800",
        "Planting": "bg-green-100 text-green-800",
        "Watering": "bg-blue-100 text-blue-800",
        "Fertilizing": "bg-yellow-100 text-yellow-800",
        "Pest Control": "bg-red-100 text-red-800",
        "Harvest": "bg-orange-100 text-orange-800",
    };

    useEffect(() => {
        setEntries(journalService.getJournalEntries());
    }, []);

    const handleAddEntry = useCallback((e: React.FormEvent) => {
        e.preventDefault();
        if (!title || !details) {
            setError('Please fill in both title and details.');
            return;
        }
        const updatedEntries = journalService.addJournalEntry({ title, details, category });
        setEntries(updatedEntries);
        setTitle('');
        setDetails('');
        setCategory('Observation');
        setError('');
    }, [title, details, category]);

    const handleDeleteEntry = useCallback((id: string) => {
        const updatedEntries = journalService.deleteJournalEntry(id);
        setEntries(updatedEntries);
    }, []);

    const handleGetAnalysis = useCallback(async () => {
        if (entries.length === 0) {
            setError("You need at least one journal entry to get an analysis.");
            return;
        }
        setLoadingAnalysis(true);
        setError('');
        setAnalysis('');
        try {
            const result = await geminiService.analyzeJournal(entries);
            setAnalysis(result);
        } catch (err) {
            setError("Sorry, an error occurred while generating your analysis.");
            console.error(err);
        } finally {
            setLoadingAnalysis(false);
        }
    }, [entries]);

    return (
        <div className="animate-fade-in">
            <h1 className="text-4xl font-bold font-serif text-gray-800 mb-2">Farm Journal</h1>
            <p className="text-lg text-gray-600 mb-6">Keep a log of your farming activities, observations, and progress.</p>

            <Card className="mb-8">
                <form onSubmit={handleAddEntry} className="space-y-4">
                    <h2 className="text-2xl font-bold text-gray-800">New Journal Entry</h2>
                    <div>
                        <label htmlFor="title" className="block text-sm font-medium text-gray-700">Title</label>
                        <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g., Planted tomato seedlings" className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-green focus:border-brand-green" />
                    </div>
                    <div>
                        <label htmlFor="details" className="block text-sm font-medium text-gray-700">Details</label>
                        <textarea id="details" value={details} onChange={e => setDetails(e.target.value)} rows={4} placeholder="e.g., Planted 10 'Celebrity' tomato seedlings in row 3. Added compost to each hole." className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-green focus:border-brand-green" />
                    </div>
                    <div>
                        <label htmlFor="category" className="block text-sm font-medium text-gray-700">Category</label>
                        <select id="category" value={category} onChange={e => setCategory(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-green focus:border-brand-green">
                            {entryCategories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                        </select>
                    </div>
                    <div className="text-right">
                        <button type="submit" className="bg-brand-green hover:bg-brand-green-dark text-white font-bold py-2 px-6 rounded-lg transition duration-300">Add Entry</button>
                    </div>
                </form>
            </Card>

            <Card className="mb-8">
                <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                    <div>
                        <h2 className="text-2xl font-bold text-gray-800">AI-Powered Insights</h2>
                        <p className="text-gray-600 mt-1">Get an intelligent summary and suggestions based on your journal.</p>
                    </div>
                    <button onClick={handleGetAnalysis} disabled={loadingAnalysis || entries.length === 0} className="bg-brand-blue hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition duration-300 disabled:bg-gray-400 flex items-center gap-2">
                        <LightbulbIcon className="w-5 h-5" />
                        {loadingAnalysis ? 'Analyzing...' : 'Get Insights'}
                    </button>
                </div>
                {loadingAnalysis && <Spinner />}
                {analysis && (
                    <div className="mt-4 border-t pt-4 prose prose-lg max-w-none prose-h3:text-brand-blue">
                        <ReactMarkdown>{analysis}</ReactMarkdown>
                    </div>
                )}
            </Card>
            
            {error && <p className="mb-4 text-center text-red-500 bg-red-100 p-3 rounded-lg">{error}</p>}

            <div>
                <h2 className="text-3xl font-bold font-serif text-gray-800 mb-4">Your Entries</h2>
                {entries.length > 0 ? (
                    <div className="space-y-4">
                        {entries.map(entry => (
                            <Card key={entry.id} className="relative">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <div className="flex items-center gap-3 mb-2">
                                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${categoryColors[entry.category] || 'bg-gray-100 text-gray-800'}`}>{entry.category}</span>
                                            <p className="text-sm text-gray-500">{new Date(entry.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                                        </div>
                                        <h3 className="text-xl font-bold text-gray-900">{entry.title}</h3>
                                    </div>
                                    <button onClick={() => handleDeleteEntry(entry.id)} className="text-gray-400 hover:text-red-600 p-1 rounded-full transition-colors duration-200" aria-label="Delete entry">
                                        <TrashIcon />
                                    </button>
                                </div>
                                <p className="mt-2 text-gray-700 whitespace-pre-wrap">{entry.details}</p>
                            </Card>
                        ))}
                    </div>
                ) : (
                    <Card>
                        <p className="text-center text-gray-500">You have no journal entries yet. Add one above to get started!</p>
                    </Card>
                )}
            </div>
        </div>
    );
};

export default FarmJournal;
